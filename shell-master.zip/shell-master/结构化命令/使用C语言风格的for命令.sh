#!/bin/bash
#testing the C-style for loop

for (( i=1; i<=10; i++ ))
do
	echo "The next number is $i"
done
