#!/bin/bash
#testing the if statement
if date
then 
	echo "it worked"
fi
echo -e '\n'
if asd
then 
	echo "it not worked"
fi
echo 'We are outside the if statement'
