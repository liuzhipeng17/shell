#!/bin/bash
#download latest cURL file automatically

curl -s -o /home/tiandi/curl
http://curl.haxx.se/download/curl
