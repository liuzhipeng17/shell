#!/bin/bash

sed '=' test | sed 'N; s/\n/ /'
