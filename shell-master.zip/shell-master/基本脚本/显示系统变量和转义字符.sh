#!/bin/bash
#display user information from system

echo "User info fro userId:$USER"
echo UID:$UID
echo HOME:$HOME
#换行
echo -e '\n'      
echo 'The cost of the item is \$15'

